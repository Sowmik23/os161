cd ~/os161/root/
sys161 kernel-ASST2

