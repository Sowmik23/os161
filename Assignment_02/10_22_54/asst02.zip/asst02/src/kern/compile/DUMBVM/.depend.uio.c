uio.o: ../../lib/uio.c ../../include/types.h ../../include/kern/types.h \
 includelinks/kern/machine/types.h includelinks/machine/types.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
 ../../include/uio.h ../../include/kern/iovec.h ../../include/proc.h \
 ../../include/spinlock.h ../../include/hangman.h opt-hangman.h \
 includelinks/machine/spinlock.h ../../include/current.h \
 includelinks/machine/current.h ../../include/thread.h \
 ../../include/array.h ../../include/threadlist.h \
 includelinks/machine/thread.h ../../include/setjmp.h \
 includelinks/kern/machine/setjmp.h ../../include/copyinout.h
