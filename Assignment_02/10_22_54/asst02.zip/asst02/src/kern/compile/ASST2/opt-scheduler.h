/* Automatically generated; do not edit */
#ifndef _OPT_SCHEDULER_H_
#define _OPT_SCHEDULER_H_
#define OPT_SCHEDULER 1
#endif /* _OPT_SCHEDULER_H_ */
