threadlist.o: ../../thread/threadlist.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/lib.h ../../include/cdefs.h \
 opt-noasserts.h ../../include/thread.h ../../include/array.h \
 ../../include/spinlock.h ../../include/hangman.h opt-hangman.h \
 includelinks/machine/spinlock.h ../../include/threadlist.h \
 includelinks/machine/thread.h ../../include/setjmp.h \
 includelinks/kern/machine/setjmp.h ../../include/clock.h \
 ../../include/kern/time.h
